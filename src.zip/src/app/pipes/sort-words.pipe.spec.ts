import { SortWordsPipe } from './sort-words.pipe';

describe('SortWordsPipe', () => {
  it('create an instance', () => {
    const pipe = new SortWordsPipe();
    expect(pipe).toBeTruthy();
  });
});
