import { ContentPipe } from './content.pipe';

describe('ContentPipe', () => {
  it('create an instance', () => {
    const pipe = new ContentPipe();
    expect(pipe).toBeTruthy();
  });
});
